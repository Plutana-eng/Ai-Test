# Test-Blue > 2025-08-13 2:18am
https://universe.roboflow.com/cs2-omg6d/test-blue-mzgz0

Provided by a Roboflow user
License: CC BY 4.0

